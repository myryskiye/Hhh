
# Luxurious Wrapped Token Generator

This is a simple decentralized application (DApp) that allows users to connect their wallets and generate wrapped tokens on BSC, Solana, and Tron networks.

## How to Use
1. **Upload this repository to GitHub**.
2. **Activate GitHub Pages** under `Settings > Pages`.
3. **Access your website** at `https://your-github-username.github.io/your-repo-name`.

## Features
- Supports MetaMask, Phantom, and TronLink wallets.
- Simple token selection and minting interface.
- Beautiful, luxurious design with animations.

## Technologies Used
- HTML, CSS, JavaScript
- Web3.js, Solana Web3.js, TronWeb

---

### Enjoy your luxurious experience! 💰🪙
